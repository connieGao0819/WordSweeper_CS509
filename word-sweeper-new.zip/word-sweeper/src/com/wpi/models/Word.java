package com.wpi.models;

import java.util.List;

public class Word {
    
    private String spell = "";
    private int score = 0;;
    
    
	public String getSpell() {
		return spell;
	}
	public void setSpell(String spell) {
		this.spell = spell;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
    
    
    
}
