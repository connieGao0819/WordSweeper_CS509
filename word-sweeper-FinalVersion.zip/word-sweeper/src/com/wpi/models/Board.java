package com.wpi.models;

import java.util.ArrayList;
import java.util.List;

import com.wpi.service.CalculateLocalScore;


public class Board {
	private List<Cell> cells;
	private List<Cell> chosenCells;
	private int globalStartingCol;
	private int globalStartingRow;
	private int up;
	private int down;
	private int left;
	private int right;
	private Integer chosenLettersScore;
	private int xbonus;
	private int ybonus;
	private int rowChange;
	private int colChange;


	
	public int getXbonus() {
		return xbonus;
	}

	public void setXbonus(int xbonus) {
		this.xbonus = xbonus;
	}

	public int getYbonus() {
		return ybonus;
	}

	public void setYbonus(int ybonus) {
		this.ybonus = ybonus;
	}

	public int getRowChange() {
		return rowChange;
	}

	public void setRowChange(int rowChange) {
		this.rowChange = rowChange;
	}

	public int getColChange() {
		return colChange;
	}

	public void setColChange(int colChange) {
		this.colChange = colChange;
	}

	public void setChosenLettersScore(Integer chosenLettersScore) {
		this.chosenLettersScore = chosenLettersScore;
	}

	public Board(List<Cell> cells, int x, int y,int size, int xbonus, int ybonus){
		this.cells = cells;
		chosenCells = new ArrayList<Cell>();
		globalStartingCol = y;
		globalStartingRow = x;
		chosenLettersScore = 0;
		up = x-1;
		down = size-x-3;
		left = y-1;
		right = size-y-3;
		this.xbonus = xbonus;
		this.ybonus = ybonus;
	}

	public int getGlobalStartingRow() {
		return globalStartingRow;
	}

	public void setGlobalStartingRow(int globalStartingRow) {
		this.globalStartingRow = globalStartingRow;
	}
	
	public List<Cell> getCells() {
		return cells;
	}

	public void setCells(List<Cell> cells) {
		this.cells = cells;
	}
	
	public void clearChosenCells(){
		chosenCells.clear();
	}

	public List<Cell> getChosenCells() {
		return chosenCells;
	}

	public void setChosenCells(List<Cell> chosenCells) {
		this.chosenCells = chosenCells;
	}

	public int getGlobalStartingCol() {
		return globalStartingCol;
	}

	public void setGlobalStartingCol(int globalStartingCol) {
		this.globalStartingCol = globalStartingCol;
	}

	public int getUp() {
		return up;
	}

	public void setUp(int up) {
		this.up = up;
	}

	public int getDown() {
		return down;
	}

	public void setDown(int down) {
		this.down = down;
	}

	public int getLeft() {
		return left;
	}

	public void setLeft(int left) {
		this.left = left;
	}

	public int getRight() {
		return right;
	}

	public void setRight(int right) {
		this.right = right;
	}

	public Integer getChosenLettersScore() {
		chosenLettersScore=0;
		if(chosenCells.size()==0){
			return 0;
		}
		chosenLettersScore =  CalculateLocalScore.calculateWordScore(this.getWord(), this.getWord().length());
		return chosenLettersScore;
	}

	public String getChosenCellsXMLString() {
		String chosenCellsString = "";
		for (Cell cell : chosenCells) {
			chosenCellsString += String.format("<cell position='%s,%s' letter='%s'/>",
					String.valueOf(cell.getCol()), String.valueOf(cell.getRow()), cell.getLetter());
		}
		return chosenCellsString;
	}

	public String getWord(){
		String word = "";
		for(Cell cell : chosenCells){
			word+=cell.getLetter();
		}
		return word;
	}

}
