package com.wpi.models;

import java.awt.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

public class Game {
	private String gameID;
	private String password;
	private Map<String, Integer> playersInfoMap;
	private Map<String, String> playersBoardPositionMap;
	private boolean isLocked;
	

	public Game(String password){
		this.password = password;
		playersInfoMap = new HashMap<String, Integer>();;
		playersBoardPositionMap = new HashMap<String, String>();
	}
	
	public Game(String id, String password) {
		this.password = password;
		gameID = id;
		playersInfoMap = new HashMap<String, Integer>();;
		playersBoardPositionMap = new HashMap<String, String>();
	}

	public String getGameID() {
		return gameID;
	}

	public void setGameID(String gameID) {
		this.gameID = gameID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Map<String, Integer> getPlayersInfoMap() {
		return playersInfoMap;
	}

	public void setPlayersInfoMap(Map<String, Integer> playersInfoMap) {
		this.playersInfoMap = playersInfoMap;
	}

	public Map<String, String> getPlayersBoardPositionMap() {
		return playersBoardPositionMap;
	}

	public void setPlayersBoardPositionMap(Map<String, String> playersBoardPositionMap) {
		this.playersBoardPositionMap = playersBoardPositionMap;
	}

	public boolean isLocked() {
		return isLocked;
	}

	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}
	
	public void addPlayerScore(String name, Integer score){
		playersInfoMap.put(name, score);
	}
	
	public int getPlayerScore(String name){
		return playersInfoMap.get(name);
	}
	
	public void addPlayerPosition(String name, String pos){
		playersBoardPositionMap.put(name, pos);
	}
	
	public String getPlayerPosition(String name){
		return playersBoardPositionMap.get(name);
	}
}
